BEGIN
DBMS_SCHEDULER.CREATE_JOB(
    JOB_NAME => 'CANCELLA_PRENOTAZIONI',
    JOB_TYPE => 'PLSQL_BLOCK',
    JOB_ACTION => 'BEGIN
                        DELETE FROM PRENOTAZIONE
                        WHERE DATA_ORA_PRENOTAZIONE<SYSDATE-365;    
                    END;',
    START_DATE => SYSDATE,
    REPEAT_INTERVAL => 'FREQ = WEEKLY',
    ENABLED => TRUE,
    COMMENTS => 'Cancellazione delle prenotazioni effettuate da più di un anno');
END;

/* CANCELLAZIONE DEL JOB

BEGIN
DBMS_SCHEDULER.DROP_JOB('CANCELLA_PRENOTAZIONI');
END;

*/